# Student Vaccination Portal
This is a web application for managing student vaccination records. It allows users to view, add, and update vaccination information for students.

## Prerequesties for backend
- Python 3.11

## Prerequesties for frontend
- Node.js 22

## Steps to run backend
   ```bash
   
   cd vaccination-portal/backend
   virtualenv venv
   source venv/bin/activate
   pip install -r requirements.txt
   python manage.py migrate
   python manage.py createsuperuser
   >> Enter username, email, and password
   python manage.py runserver 8080
   
   ```

## Steps to run frontend
   ```bash
   cd vaccination-portal/frontend
   npm install
   npm run dev
   ```