import { Box, IconButton } from "@mui/material"
import ChevronLeftIcon from '@mui/icons-material/ChevronLeft';


const DrawToggle = ({ draw, setDraw }) => {

    return (
        <Box sx={{ height: "50px", display:"flex", alignItems: "center", justifyContent: "center" }}>
            <IconButton>
                <ChevronLeftIcon />
            </IconButton>
        </Box>
    )
}