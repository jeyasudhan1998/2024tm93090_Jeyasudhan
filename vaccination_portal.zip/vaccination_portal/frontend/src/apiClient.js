// apiClient.js
import axios from 'axios';
import { API_URL } from './config';
import { useNavigate } from 'react-router-dom';

// Create an axios instance with the base URL
const apiClient = axios.create({
  baseURL: API_URL,
  headers: {
    'Content-Type': 'application/json',
  },
});

apiClient.interceptors.request.use(
    (config) => {
      const token = localStorage.getItem('access');
      if (token) {
        config.headers.Authorization = `Bearer ${token}`;
      }
      return config;
    },
    (error) => Promise.reject(error)
  );
  
  
  apiClient.interceptors.response.use(
      (response) => response,
      async (error) => {
        const originalRequest = error.config;
        const navigate = useNavigate();
    
        // If the error status is 401 and there is no originalRequest._retry flag,
        // it means the token has expired and we need to refresh it
        if (error.response) {
            if (error.response.status === 401 && !originalRequest._retry) {
                originalRequest._retry = true;
                try {
                    const refreshToken = localStorage.getItem('refresh');
                    const { data } = await axios.post('api/token/refresh/', {
                        refresh: refreshToken,
                    });
                    localStorage.setItem('access', data.access);
                    originalRequest.headers['Authorization'] = `Bearer ${data.access}`;
                    return axios(originalRequest);
                } catch (refreshError) {
                    console.error('Token refresh failed:', refreshError);
                    navigate('/login');
                }
            }
        } else {
            console.error('Network or other error:', error.message);
        }
    
        return Promise.reject(error);
      }
    );
  

// Example of a GET request
export const fetchData = async (endpoint) => {
  try {
    const response = await apiClient.get(endpoint);
    return response;
  } catch (error) {
    console.error('API call failed:', error);
    throw error;
  }
};

// Example of a POST request
export const postData = async (endpoint, data) => {
  try {
    const response = await apiClient.post(endpoint, data);
    return response;
  } catch (error) {
    console.error('API call failed:', error);
    throw error;
  }
};

export default apiClient;