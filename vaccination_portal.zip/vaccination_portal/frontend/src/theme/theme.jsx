import { createTheme } from "@mui/material";

export const createMuiTheme = (mode) => {
    return createTheme({
        PrimaryAppBar: {
            height: 50,
            backgroundColor: mode === 'light' ? '#1976d2' : '#90caf9',
            color: mode === 'light' ? '#fff' : '#000',
        },
        PrimaryDraw: {
            width: 240,
        },
        components: {
            MuiAppBar: {
                defaultProps: {
                    color: 'default',
                    elevation: 0,
                },
            },
        },
    });
}

export const theme = createMuiTheme('light');