import { createBrowserRouter, createRoutesFromElements, Route, RouterProvider, redirect } from 'react-router-dom'

import Login from './pages/Login';
import Home from './pages/Home';

import './App.css'
import { ThemeProvider } from '@emotion/react';
import { createMuiTheme } from './theme/theme';


const isAuthenticated = () => {
  // Replace this with your actual authentication logic
  return localStorage.getItem('access') !== null;
};

// Loader function to check authentication
const requireAuth = async () => {
  if (!isAuthenticated()) {
    throw redirect('/login'); // Redirect to login if not authenticated
  }
};


const router = createBrowserRouter(
  createRoutesFromElements(
    <Route>
      <Route path="/login" element={<Login />} />
      <Route path="/*" element={<Home />} loader={requireAuth} />
      
    </Route>
  )
)

function App() {
  const theme = createMuiTheme();

  return (
  <ThemeProvider theme={theme}>
    <RouterProvider router={router} />
  </ThemeProvider>
  )
}

export default App
