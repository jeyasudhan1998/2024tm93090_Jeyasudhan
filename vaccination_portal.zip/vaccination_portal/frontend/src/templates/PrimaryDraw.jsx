import { Box, Drawer } from "@mui/material";
import { useTheme } from "@mui/material/styles";
import { useState } from "react";
import DrawToggle from "../components/PrimaryDraw/DrawToggle.jsx";


const PrimaryDraw = () => {
    const theme = useTheme();
    const [open, setOpen] = useState(true);

    const handleDrawerOpen = () => {
        setOpen(true);
    }

    const handleDrawerClose = () => {
        setOpen(false);
    }


    return (
        <Drawer 
            open={open} 
            PaperProps={{ 
                sx: { 
                    mt: `${theme.PrimatyAppBar.height}px`, 
                    height: `calc(100vh - ${theme.PrimatyAppBar.height})px`, 
                    width: theme.PrimaryDraw.width,
                } 
            }}
        >
            <Box>
                <Box sx={{ display: { xs: "block", sm: "none" }}}>
                    <DrawToggle draw={open} setDraw={setOpen} />
                </Box>
            </Box>
        </Drawer>
    );
    }

export default PrimaryDraw;