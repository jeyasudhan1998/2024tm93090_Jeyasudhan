import React, { useState } from 'react';
import "./Login.css";
import { postData } from '../apiClient';

import { useNavigate } from 'react-router-dom';

const Login = () => {
    const navigate = useNavigate();

    const [credentials, setCredentials] = useState({
        username: '',
        password: ''
    });
    
    const handleChange = (e) => {
        console.log("calling");
        
        setCredentials({
            ...credentials,
            [e.target.name]: e.target.value
        });
    };

    
    const handleSubmit = async (e) => {
        e.preventDefault();

        try {
            const response = await postData('/token/', {username: credentials.username, password: credentials.password});
            if (response.status === 200) {
                console.log("response", response);
                
                const { access, refresh } = response.data;
                localStorage.setItem('access', access);
                localStorage.setItem('refresh', refresh); 
                navigate('/');
            } else {
                // Handle authentication error
                console.error('Authentication failed');
            }
        } catch (error) {
            // Handle network or other errors
            console.error('An error occurred', error);
        }
    };

    return (
        <div className="login-container">
        <h1 className="login-title">Login</h1>
        <form className="login-form" onSubmit={handleSubmit}>
            <div className="form-group">
                <label>Email:</label>
                <input
                    type="text"
                    name='username'
                    value={credentials.usernmae}
                    onChange={handleChange}
                    className="form-input"
                />
            </div>
            <div className="form-group">
                <label>Password:</label>
                <input
                    type="password"
                    name='password'
                    value={credentials.password}
                    onChange={handleChange}
                    className="form-input"
                />
            </div>
            <button type="submit" className="login-button">Login</button>
        </form>
    </div>
    );
};

export default Login;