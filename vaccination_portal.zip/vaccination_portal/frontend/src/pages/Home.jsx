import React from 'react';
import { Routes, Route } from 'react-router-dom';
import { CssBaseline } from '@mui/material';
import PrimaryAppBar from '../templates/PrimaryAppBar.jsx';
import Dashboard from '../pages/Dashboard.jsx'
// import Vaccines from '../pages/Vaccines.jsx';
import Students from '../pages/Students.jsx'

const Home = () => {
    return (
        <div className="home">
            <CssBaseline />
            <PrimaryAppBar />
            <div style={{ marginTop: '64px', padding: '16px' }}> {/* Add margin to avoid overlap */}
                <Routes>
                    <Route path="/" element={<Dashboard />} /> {/* Default route */}
                    <Route path="/students" element={<Students />} />
                    {/* // <Route path="/vaccines" element={<Vaccines />} /> */}
                </Routes>
            </div>
        </div>
    )
}

export default Home;