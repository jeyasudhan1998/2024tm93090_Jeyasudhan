const Students = () => {
    return (
        <div className="students">
            <h1>Students</h1>
            {/* Add your student management components here */}
        </div>
    )
}

export default Students;