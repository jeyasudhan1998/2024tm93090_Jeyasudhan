import React, { useState, useEffect } from "react";
import { Box, Button, Dialog, DialogTitle, DialogContent, DialogActions, TextField, Select, FormControl, InputLabel, MenuItem } from "@mui/material";
import { DatePicker } from "@mui/x-date-pickers";
import { LocalizationProvider } from "@mui/x-date-pickers/LocalizationProvider";
import { AdapterDayjs } from "@mui/x-date-pickers/AdapterDayjs";
import { fetchData, postData } from "../apiClient";


const Dashboard = () => {

    const [drives, setDrives] = useState([]);
    const [vaccines, setVaccines] = useState([]);

    const [driveName, setDriveName] = useState('');
    const [selectedDate, setSelectedDate] = useState(null);
    const [selectedVaccine, setSelectedVaccine] = useState(null);
    const [doseCount, setDoseCount] = useState(0);

    const [vaccineName, setVaccineName] = useState('');
    const [vaccineDose, setVaccineDose] = useState('');

    const [openDrive, setOpenDrive] = useState(false);
    const [openVaccine, setOpenVaccine] = useState(false);

    const handleOpenDrive = () => {
        setOpenDrive(true);
    };

    const handleCloseDrive = () => {
        setOpenDrive(false);
    };

    const handleOpenVaccine = () => {
        setOpenVaccine(true);
    };

    const handleCloseVaccine = () => {
        setOpenVaccine(false);
    };


    useEffect(() => {
        const fetchDataAsync = async () => {
            try {
                const response = await fetchData('/vaccination_drives/');
                setDrives(response.data);
            } catch (error) {
                console.error('Failed to fetch drives', error);
            }
        };
    
        fetchDataAsync();
    
        // Cleanup function (if needed)
        return () => {
            // Ensure this is a valid function
        };
    }, []);

    useEffect(() => {
        const fetchDataAsync = async () => {
            try {
                const response = await fetchData('/vaccines/');
                setVaccines(response.data);
            } catch (error) {
                console.error('Failed to fetch vaccines', error);
            }
        };
    
        fetchDataAsync();
        return () => {};
    }, []);

    const handleSubmit = async () => {
        // Handle registration logic here
            const formattedDate = selectedDate.toISOString().split('T')[0];
            await postData('/vaccination_drives/', {
                name: driveName,
                date: formattedDate,
                vaccine: selectedVaccine,
                no_of_doses_available: doseCount,
            }).then((response) => {
                console.log('Registration successful', response.data);
            }).catch((error) => {
                // Handle error
                console.error('Registration failed', error);
            })
        handleCloseDrive();
    };

    const handleSubmitVaccine = async () => {
        await postData('/vaccines/', {
            name: vaccineName,
            dose: vaccineDose,
        })
        .then((response) => {
            console.log('Vaccine created successfully', response.data);
        }).catch((error) => {
            console.error('Failed to create vaccine', error);
        });
        handleCloseVaccine();
    };

    const registerDriveComponent = () => {
        return (
            <Button variant="contained" color="primary" onClick={handleOpenDrive}>
                Register Drive
            </Button>
        );
    };

    const createVaccineComponent = () => {
        return (
            <Button variant="contained" color="secondary" onClick={handleOpenVaccine}>
                Create Vaccine
            </Button>
        );
    }

    return (
        <div>
            <Box sx={{ marginBottom: 2 }}>
                {registerDriveComponent()}
            </Box>
            
            <Box sx={{ marginBottom: 2 }}>
                {createVaccineComponent()}
            </Box>

            {/* Modal for Register Drive */}
            <Dialog open={openDrive} onClose={handleCloseDrive}>
                <DialogTitle>Create Register Drive</DialogTitle>
                <DialogContent>
                    <TextField
                        autoFocus
                        margin="dense"
                        label="Drive Name"
                        type="text"
                        fullWidth
                        variant="outlined"
                        value={driveName}
                        onChange={(e) => setDriveName(e.target.value)}
                    />
                    <LocalizationProvider dateAdapter={AdapterDayjs}>
                        <DatePicker
                            label="Date"
                            value={selectedDate}
                            onChange={(newValue) => setSelectedDate(newValue)}
                            renderInput={(params) => <TextField {...params} fullWidth margin="dense" />}
                        />
                    </LocalizationProvider>
                    <FormControl fullWidth margin="dense" variant="outlined">
                        <InputLabel id="location-label">Vaccine Name</InputLabel>
                        <Select
                            labelId="vaccine-label"
                            value={selectedVaccine}
                            onChange={(e) => setSelectedVaccine(e.target.value)}
                            label="Location"
                        >
                            {vaccines.map((vaccine) => (
                                <MenuItem key={vaccine.id} value={vaccine.id}>
                                    {vaccine.name} - {vaccine.dose}
                                </MenuItem>
                            ))}
                        </Select>
                    </FormControl>
                    <TextField
                        margin="dense"
                        label="No of Doses Available"
                        type="number"
                        fullWidth
                        variant="outlined"
                        value={doseCount}
                        onChange={(e) => setDoseCount(e.target.value)}
                    />
                </DialogContent>
                <DialogActions>
                    <Button onClick={handleCloseDrive} color="secondary">
                        Cancel
                    </Button>
                    <Button onClick={handleSubmit} color="primary">
                        Submit
                    </Button>
                </DialogActions>
            </Dialog>

            {/* Modal for Create Vaccine */}
            <Dialog open={openVaccine} onClose={handleCloseVaccine}>
                <DialogTitle>Create Vaccine</DialogTitle>
                <DialogContent>
                    <TextField
                        margin="dense"
                        label="Vaccine Name"
                        type="text"
                        fullWidth
                        variant="outlined"
                        value={vaccineName}
                        onChange={(e) => setVaccineName(e.target.value)}
                    />
                    <TextField
                        margin="dense"
                        label="Vaccine Dose"
                        type="text"
                        fullWidth
                        variant="outlined"
                        value={vaccineDose}
                        onChange={(e) => setVaccineDose(e.target.value)}
                    />
                </DialogContent>
                <DialogActions>
                    <Button onClick={handleCloseVaccine} color="secondary">
                        Cancel
                    </Button>
                    <Button onClick={handleSubmitVaccine} color="primary">
                        Submit
                    </Button>
                </DialogActions>
            </Dialog>

            <h1>Upcoming Drives</h1>
            {drives && drives.length > 0 ? (
                drives.map((drive) => (
                    <Box 
                        key={drive.id}
                        sx={{
                            border: '1px solid #ccc',
                            borderRadius: '8px',
                            padding: '16px',
                            marginBottom: '16px',
                            boxShadow: '0 2px 4px rgba(0, 0, 0, 0.1)',
                            backgroundColor: '#f9f9f9',
                        }}
                    >
                        <h2>{drive.name}</h2>
                        <p>{drive.description}</p>
                        <p>{new Date(drive.date).toLocaleDateString()}</p>
                        <Button 
                            variant="contained" 
                            color="primary" 
                            onClick={() => handleRegister(drive.id)}
                        >
                            Register
                        </Button>
                    </Box>
                ))
            ) : (
                <p>No drives available</p>
            )}
        </div>
    )
}

export default Dashboard;