export const API_URL = 'http://localhost:8082/api'; // Base URL for the API
export const MEDICAL_API_URL = 'http://localhost:8000'; // Base URL for the medical API