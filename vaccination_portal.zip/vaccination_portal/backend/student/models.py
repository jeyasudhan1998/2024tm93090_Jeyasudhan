from django.db import models


class Student(models.Model):
    first_name = models.CharField(max_length=30)
    last_name = models.CharField(max_length=30)
    roll_number = models.IntegerField()
    class_name = models.CharField(max_length=10)
    section = models.CharField(max_length=1)
    email_address = models.EmailField(max_length=120, blank=True, null=True)
    contact_number = models.CharField(max_length=15, blank=True, null=True)
    vaccines = models.ManyToManyField('vaccination.Vaccine', related_name='students')

    def __str__(self):
        return f"{self.first_name} {self.last_name} - {self.roll_number}"




