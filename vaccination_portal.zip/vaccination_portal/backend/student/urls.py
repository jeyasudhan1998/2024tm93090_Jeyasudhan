from django.urls import path

from .views import BulkUploadStudentViewSet, StudentDetails

from rest_framework.routers import DefaultRouter

router = DefaultRouter()
router.register('students', StudentDetails, basename='student')

urlpatterns = [
    path('create_students/', BulkUploadStudentViewSet.as_view()),
] + router.urls