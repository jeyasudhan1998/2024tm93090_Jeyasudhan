from rest_framework import serializers

from vaccination.serializer import VaccineSerializer
from .models import Student


class StudentSerializer(serializers.ModelSerializer):

    class Meta:
        model = Student
        fields = ['id', 'first_name', 'last_name', 'roll_number', 'class_name', 'section']
        read_only_fields = ['id']

    def create(self, validated_data):
        """
        Create and return a new `Student` instance, given the validated data.
        """
        student = Student.objects.create(**validated_data)
        return student


class StudentVaccinationSerializer(serializers.ModelSerializer):
    """
    Serializer for student vaccination details.
    """
    vaccines = serializers.SerializerMethodField()

    class Meta:
        model = Student
        fields = ['id', 'first_name', 'last_name', 'roll_number', 'class_name', 'section']
        read_only_fields = ['id']

    def get_vaccines(self, obj):
        """
        Get the list of vaccines for the student.
        """
        vaccines = obj.vaccines.all()
        return VaccineSerializer(vaccines, many=True).data
