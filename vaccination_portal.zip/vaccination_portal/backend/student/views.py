from rest_framework import viewsets, status
from rest_framework.views import APIView
from rest_framework.response import Response

from student.models import Student
from student.serializer import StudentSerializer, StudentVaccinationSerializer


class StudentDetails(viewsets.ReadOnlyModelViewSet):
    queryset = Student.objects.all()
    serializer_class = StudentVaccinationSerializer

    def retrieve(self, request, *args, **kwargs):
        """
        Retrieve a student instance along with vaccination details.
        """
        student = self.get_object()
        serializer = self.get_serializer(student)
        return Response(serializer.data)

    def list(self, request, *args, **kwargs):
        """
        List all student instances with vaccination details.
        """
        queryset = self.get_queryset()
        serializer = self.get_serializer(queryset, many=True)
        return Response(serializer.data)


class BulkUploadStudentViewSet(APIView):
    """
    A viewset for bulk uploading student instances.
    """
    queryset = Student.objects.all()
    serializer_class = StudentSerializer

    def post(self, request, *args, **kwargs):
        """
        Create multiple student instances from a CSV file.
        """
        file = request.FILES.get('file')
        if not file:
            return Response({"error": "No file provided"}, status=status.HTTP_400_BAD_REQUEST)

        import csv
        from io import TextIOWrapper

        csv_file = TextIOWrapper(file.file, encoding='utf-8')
        reader = csv.DictReader(csv_file)
        students = []
        for row in reader:
            student_data = {
                'first_name': row['first_name'],
                'last_name': row['last_name'],
                'roll_number': row['roll_number'],
                'class_name': row['class_name'],
                'section': row['section'],
            }
            serializer = self.get_serializer(data=student_data)
            serializer.is_valid(raise_exception=True)
            students.append(serializer.save())

        return Response({"message": "Students created successfully"}, status=status.HTTP_201_CREATED)