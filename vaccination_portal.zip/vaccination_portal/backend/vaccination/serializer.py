from rest_framework.serializers import ModelSerializer

from .models import *


class VaccineSerializer(ModelSerializer):
    class Meta:
        model = Vaccine
        fields = '__all__'
        read_only_fields = ['id']

    def create(self, validated_data):
        vaccine = Vaccine.objects.create(**validated_data)
        return vaccine


class VaccinationDriveSerializer(ModelSerializer):
    class Meta:
        model = VaccinationDrive
        fields = '__all__'
        read_only_fields = ['id']

    def create(self, validated_data):
        vaccination_drive = VaccinationDrive.objects.create(**validated_data)
        return vaccination_drive


class RegisterVaccinationDriveSerializer(ModelSerializer):
    class Meta:
        model = RegisterVaccinationDrive
        fields = '__all__'
        read_only_fields = ['id']

    def create(self, validated_data):
        register_vaccination_drive = RegisterVaccinationDrive.objects.create(**validated_data)
        return register_vaccination_drive
