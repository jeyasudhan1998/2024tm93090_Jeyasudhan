from django.db import models


class Vaccine(models.Model):
    name = models.CharField(max_length=100)
    dose = models.CharField(max_length=50)
    age_group = models.CharField(max_length=2, blank=True, null=True)
    min_class = models.CharField(max_length=2, blank=True, null=True)
    side_effects = models.TextField(null=True, blank=True)

    def __str__(self):
        return self.name


class VaccinationDrive(models.Model):
    """
    If there are no vaccination drives, it should display a message “no upcoming drives”.
    The status of number of students registered vs number of them vaccinated to be displayed.
    """
    name = models.CharField(max_length=100, blank=True, null=True)
    vaccine = models.ForeignKey(Vaccine, on_delete=models.CASCADE, related_name='vaccinations')
    date = models.DateField()
    no_of_doses_available = models.IntegerField(default=0)

    def __str__(self):
        return f"{self.student} - {self.vaccine} - Dose {self.dose_number}"


class RegisterVaccinationDrive(models.Model):
    """
    This model is used to register a vaccination drive.
    """
    student = models.ForeignKey('student.Student', on_delete=models.CASCADE, related_name='vaccination_drive')
    drive = models.ForeignKey(VaccinationDrive, on_delete=models.CASCADE, related_name='drives')

