from datetime import date

from student.models import Student
from student.serializer import StudentSerializer
from .models import Vaccine, VaccinationDrive, RegisterVaccinationDrive

from rest_framework.views import APIView

from rest_framework.response import Response

from rest_framework import status

from .serializer import VaccineSerializer, VaccinationDriveSerializer, RegisterVaccinationDriveSerializer


class VaccinesView(APIView):
    """
    API view to retrieve and create vaccines.
    """
    def get(self, request, pk=None):
        """
        Retrieve all vaccines.
        """
        if pk:
            try:
                vaccine = Vaccine.objects.get(pk=pk)
                serializer = VaccineSerializer(vaccine)
                return Response(serializer.data)
            except Vaccine.DoesNotExist:
                return Response({"error": "Vaccine not found"}, status=status.HTTP_404_NOT_FOUND)

        vaccines = Vaccine.objects.all()
        serializer = VaccineSerializer(vaccines, many=True)
        return Response(serializer.data)

    def post(self, request):
        """
        Create a new vaccine.
        """
        serializer = VaccineSerializer(data=request.data)
        if serializer.is_valid():
            serializer.save()
            return Response(serializer.data, status=status.HTTP_201_CREATED)
        return Response(serializer.errors, status=status.HTTP_400_BAD_REQUEST)


class VaccinationDriveView(APIView):
    """
    API view to retrieve and create vaccination drives.
    """
    def get(self, request, pk=None):
        """
        Retrieve all vaccination drives.
        """
        if pk:
            try:
                vaccination_drive = VaccinationDrive.objects.get(pk=pk)
                serializer = VaccinationDriveSerializer(vaccination_drive)
                return Response(serializer.data)
            except VaccinationDrive.DoesNotExist:
                return Response({"error": "Vaccination drive not found"}, status=status.HTTP_404_NOT_FOUND)

        vaccination_drives = VaccinationDrive.objects.filter(date__gte=date.today())
        # if not vaccination_drives.exists():
        #     return Response({"message": "No upcoming drives"}, status=status.HTTP_200_OK)

        serializer = VaccinationDriveSerializer(vaccination_drives, many=True)
        return Response(serializer.data)

    def post(self, request):
        """
        Create a new vaccination drive.
        """
        serializer = VaccinationDriveSerializer(data=request.data)
        if serializer.is_valid():
            serializer.save()
            return Response(serializer.data, status=status.HTTP_201_CREATED)
        return Response(serializer.errors, status=status.HTTP_400_BAD_REQUEST)


class RegisterVaccinationDriveView(APIView):
    """
    API view to register a student for a vaccination drive.
    """
    def post(self, request):
        """
        Register a student for a vaccination drive.
        """
        serializer = RegisterVaccinationDriveSerializer(data=request.data)
        if serializer.is_valid():
            serializer.save()
            return Response(serializer.data, status=status.HTTP_201_CREATED)
        return Response(serializer.errors, status=status.HTTP_400_BAD_REQUEST)

    def get(self, request, pk):
        """
        get registered students
        """
        queryset = RegisterVaccinationDrive.objects.get(pk=pk)
        serializer = StudentSerializer(queryset.student)
        return Response(serializer.data)


class UpdateVaccinateStudentView(APIView):
    """
    API view to update the vaccination status of a student.
    """
    def put(self, request, pk):
        """
        Update the vaccination status of a student.
        """
        student = Student.objects.get(pk=pk)
        vaccine = Vaccine.objects.get(pk=request.data.get('vaccine'))
        student.vaccines.add(vaccine)
        return Response({"success": "Vaccination registered on student"})