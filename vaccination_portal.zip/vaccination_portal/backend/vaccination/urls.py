from django.urls import path

from .views import *

urlpatterns = [
    path('add_vaccine_to_student/', UpdateVaccinateStudentView.as_view()),
    path('vaccination_drives/', VaccinationDriveView.as_view()),
    path('vaccination_drives/<int:pk>/', VaccinationDriveView.as_view()),
    path('vaccines/', VaccinesView.as_view()),
    path('vaccines/<int:pk>/', VaccinesView.as_view()),
    path('register_vaccination_drive/', RegisterVaccinationDriveView.as_view()),
]